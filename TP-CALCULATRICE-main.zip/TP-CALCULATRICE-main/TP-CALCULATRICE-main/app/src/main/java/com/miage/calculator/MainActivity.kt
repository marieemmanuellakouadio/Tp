package com.miage.calculator

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.miage.calculator.databinding.ActivityMainBinding

/**
 * MainActivity - Application Calculatrice
 * Master 2 MIAGE - MMM - TP1
 *
 * Fonctionnalités:
 * - Opérations arithmétiques de base: +, -, *, /, %
 * - Négation (moins unaire)
 * - Suppression du dernier caractère
 * - Effacement complet
 * - Calcul automatique lors de la saisie d'une nouvelle opération
 * - Préservation de l'état lors de la rotation de l'écran
 * - Copie du résultat dans le presse-papiers
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // Variables d'état de la calculatrice
    private var displayText: String = ""
    private var firstOperand: Double? = null
    private var currentOperation: String? = null
    private var isNewNumber: Boolean = true
    private var waitingForOperand: Boolean = false

    companion object {
        private const val TAG = "Calculator"
        // Clés pour sauvegarder l'état lors des changements de configuration
        private const val KEY_DISPLAY = "display"
        private const val KEY_FIRST_OPERAND = "first_operand"
        private const val KEY_OPERATION = "operation"
        private const val KEY_IS_NEW_NUMBER = "is_new_number"
        private const val KEY_WAITING_FOR_OPERAND = "waiting_for_operand"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialiser le View Binding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Restaurer l'état si disponible (rotation d'écran)
        if (savedInstanceState != null) {
            displayText = savedInstanceState.getString(KEY_DISPLAY) ?: ""
            if (savedInstanceState.containsKey(KEY_FIRST_OPERAND)) {
                firstOperand = savedInstanceState.getDouble(KEY_FIRST_OPERAND)
            }
            currentOperation = savedInstanceState.getString(KEY_OPERATION)
            isNewNumber = savedInstanceState.getBoolean(KEY_IS_NEW_NUMBER, true)
            waitingForOperand = savedInstanceState.getBoolean(KEY_WAITING_FOR_OPERAND, false)

            Log.d(TAG, "Restored state: display='$displayText', first=$firstOperand, op=$currentOperation")
        }

        setupClickListeners()

        // Toujours mettre à jour l'affichage après la configuration
        binding.displayText.post {
            updateDisplay()
        }
    }

    /**
     * Sauvegarder l'état de la calculatrice avant changement de configuration (rotation)
     */
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString(KEY_DISPLAY, displayText)
        firstOperand?.let { outState.putDouble(KEY_FIRST_OPERAND, it) }
        outState.putString(KEY_OPERATION, currentOperation)
        outState.putBoolean(KEY_IS_NEW_NUMBER, isNewNumber)
        outState.putBoolean(KEY_WAITING_FOR_OPERAND, waitingForOperand)
    }

    /**
     * Configurer les écouteurs de clics pour tous les boutons
     */
    private fun setupClickListeners() {
        // Boutons de chiffres (0-9)
        binding.button0.setOnClickListener { onDigitClick("0") }
        binding.button1.setOnClickListener { onDigitClick("1") }
        binding.button2.setOnClickListener { onDigitClick("2") }
        binding.button3.setOnClickListener { onDigitClick("3") }
        binding.button4.setOnClickListener { onDigitClick("4") }
        binding.button5.setOnClickListener { onDigitClick("5") }
        binding.button6.setOnClickListener { onDigitClick("6") }
        binding.button7.setOnClickListener { onDigitClick("7") }
        binding.button8.setOnClickListener { onDigitClick("8") }
        binding.button9.setOnClickListener { onDigitClick("9") }

        // Bouton décimal
        binding.buttonDecimal.setOnClickListener { onDecimalClick() }

        // Boutons d'opération
        binding.buttonAdd.setOnClickListener { onOperationClick("+") }
        binding.buttonSubtract.setOnClickListener { onOperationClick("-") }
        binding.buttonMultiply.setOnClickListener { onOperationClick("*") }
        binding.buttonDivide.setOnClickListener { onOperationClick("/") }
        binding.buttonModulo.setOnClickListener { onOperationClick("%") }

        // Boutons de fonction spéciaux
        binding.buttonEquals.setOnClickListener { onEqualsClick() }
        binding.buttonNegate.setOnClickListener { onNegateClick() }
        binding.buttonDelete.setOnClickListener { onDeleteClick() }
        binding.buttonClear.setOnClickListener { onClearClick() }

        // Appui long sur l'affichage pour copier dans le presse-papiers
        binding.displayText.setOnLongClickListener {
            copyToClipboard()
            true
        }
    }

    /**
     * Gérer les clics sur les boutons de chiffres
     * Exigence: Cliquer sur un chiffre l'ajoute à la fin de la ligne d'affichage
     */
    private fun onDigitClick(digit: String) {
        if (waitingForOperand) {
            // Ajouter le chiffre après l'opération
            displayText += digit
            waitingForOperand = false
            isNewNumber = false
        } else if (isNewNumber) {
            // Commencer un nouveau nombre
            displayText = digit
            isNewNumber = false
        } else {
            // Ajouter le chiffre au nombre actuel
            displayText += digit
        }
        Log.d(TAG, "Digit clicked: $digit, display='$displayText'")
        updateDisplay()
    }

    /**
     * Gérer le clic sur le bouton décimal
     */
    private fun onDecimalClick() {
        if (waitingForOperand) {
            // Ajouter 0. après l'opération
            displayText += "0."
            waitingForOperand = false
            isNewNumber = false
        } else if (isNewNumber) {
            // Commencer un nouveau nombre avec 0.
            displayText = "0."
            isNewNumber = false
        } else {
            // Obtenir le dernier nombre dans l'affichage
            val parts = displayText.split(" ")
            val lastNumber = parts.last()

            // Ajouter un point décimal seulement s'il n'y en a pas déjà un
            if (!lastNumber.contains(".")) {
                displayText += "."
            }
        }
        Log.d(TAG, "Decimal clicked, display='$displayText'")
        updateDisplay()
    }

    /**
     * Gérer les clics sur les boutons d'opération
     * Exigence: Si la ligne contient déjà une opération, cette opération est effectuée
     * et son résultat est affiché avant d'afficher la nouvelle opération
     */
    private fun onOperationClick(operation: String) {
        // Obtenir la valeur actuelle
        val parts = displayText.split(" ")
        val currentValue = parts.last().toDoubleOrNull()

        if (currentValue == null) return

        // Si une opération est en attente et qu'on n'attend pas d'opérande, calculer d'abord
        if (currentOperation != null && !waitingForOperand) {
            val first = firstOperand ?: return
            val result = performCalculation(first, currentValue, currentOperation!!)
            if (result != null) {
                firstOperand = result
                displayText = formatResult(result)
            } else {
                return
            }
        } else {
            firstOperand = currentValue
        }

        currentOperation = operation
        displayText += " $operation "
        waitingForOperand = true
        isNewNumber = false
        updateDisplay()
    }

    /**
     * Gérer le clic sur le bouton égal
     * Exigence: Lorsqu'il y a une opération, cliquer sur "=" effectue l'opération
     * et affiche le résultat. S'il n'y a pas d'opération, rien n'est modifié.
     */
    private fun onEqualsClick() {
        Log.d(TAG, "Equals clicked: display='$displayText', op=$currentOperation, waiting=$waitingForOperand")

        // Vérifier qu'il y a une opération en cours
        if (currentOperation == null) {
            Log.d(TAG, "No operation, ignoring")
            return
        }

        // Vérifier qu'on n'attend pas d'opérande
        if (waitingForOperand) {
            Log.d(TAG, "Waiting for operand, ignoring")
            return
        }

        // Calculer le résultat
        calculateResult()
    }

    /**
     * Calculer le résultat de l'opération actuelle
     */
    private fun calculateResult() {
        // Vérifier qu'on a un premier opérande
        val first = firstOperand
        if (first == null) return

        // Vérifier qu'on a une opération
        val operation = currentOperation
        if (operation == null) return

        // Extraire le deuxième opérande du texte d'affichage
        val parts = displayText.split(" ")
        if (parts.size < 3) return

        // Obtenir le dernier nombre
        val lastPart = parts.last()
        val secondOperand = lastPart.toDoubleOrNull()
        if (secondOperand == null) return

        // Effectuer le calcul
        val result = performCalculation(first, secondOperand, operation)
        if (result != null) {
            displayText = formatResult(result)
            firstOperand = result
            currentOperation = null
            waitingForOperand = false
            isNewNumber = true
            updateDisplay()
        }
    }

    /**
     * Effectuer le calcul entre deux opérandes
     */
    private fun performCalculation(first: Double, second: Double, operation: String): Double? {
        return when (operation) {
            "+" -> first + second
            "-" -> first - second
            "*" -> first * second
            "/" -> {
                if (second == 0.0) {
                    Toast.makeText(this, "Division par zéro", Toast.LENGTH_SHORT).show()
                    return null
                }
                first / second
            }
            "%" -> {
                if (second == 0.0) {
                    Toast.makeText(this, "Modulo par zéro", Toast.LENGTH_SHORT).show()
                    return null
                }
                first % second
            }
            else -> null
        }
    }

    /**
     * Formater le résultat (supprimer les décimales inutiles)
     */
    private fun formatResult(result: Double): String {
        return if (result % 1.0 == 0.0) {
            result.toLong().toString()
        } else {
            // Limiter à 10 décimales pour éviter les erreurs d'arrondi
            String.format("%.10f", result).trimEnd('0').trimEnd('.')
        }
    }

    /**
     * Gérer le clic sur le bouton de négation
     * Exigence: Remplace le dernier nombre saisi par son opposé (bascule négatif/positif)
     */
    private fun onNegateClick() {
        if (displayText.isEmpty()) return

        val parts = displayText.split(" ")
        val lastNumber = parts.last()

        if (lastNumber.isEmpty()) return

        val negated = if (lastNumber.startsWith("-")) {
            lastNumber.substring(1)
        } else {
            "-$lastNumber"
        }

        // Reconstruire le texte d'affichage avec le nombre inversé
        if (parts.size > 1) {
            displayText = parts.dropLast(1).joinToString(" ") + " $negated"
        } else {
            displayText = negated
        }

        updateDisplay()
    }

    /**
     * Gérer le clic sur le bouton de suppression
     * Exigence: Supprime le dernier caractère, qu'il s'agisse d'un chiffre ou d'une opération
     * - La suppression du dernier chiffre ne doit PAS afficher un zéro
     * - Pour les nombres négatifs: lors de la suppression d'un nombre négatif à un chiffre,
     *   le signe moins est supprimé avec le chiffre
     */
    private fun onDeleteClick() {
        if (displayText.isEmpty()) return

        // Cas 1: Supprimer une opération (se termine par un espace après l'opérateur)
        // Les opérations sont stockées comme " + "
        if (displayText.endsWith(" ")) {
            // On enlève l'espace, l'opérateur et l'espace avant
            displayText = displayText.trimEnd().dropLast(1).trimEnd()
            currentOperation = null
            // On n'attend plus d'opérande car on est revenu au premier nombre
            waitingForOperand = false
            isNewNumber = false
            Log.d(TAG, "Delete: removed operation, display='$displayText'")
            updateDisplay()
            return
        }

        val parts = displayText.split(" ")
        val lastPart = parts.last()

        // Cas 2: Nombre négatif à un seul chiffre (ex: "-5")
        // Exigence: Supprimer le signe moins ET le chiffre ensemble
        if (lastPart.matches(Regex("^-\\d$"))) {
            if (parts.size > 1) {
                // Il y a une opération avant (ex: "10 + -5" -> "10 + ")
                displayText = parts.dropLast(1).joinToString(" ") + " "
                waitingForOperand = true
            } else {
                // C'est juste "-5" seul -> on vide tout
                displayText = ""
                isNewNumber = true
                waitingForOperand = false
            }
            Log.d(TAG, "Delete: removed single-digit negative number, display='$displayText'")
            updateDisplay()
            return
        }

        // Cas 3: Dernier caractère standard d'un nombre
        if (displayText.isNotEmpty()) {
            displayText = displayText.dropLast(1)

            // Si on vient de supprimer le dernier chiffre et qu'on retombe sur l'espace d'une opération
            if (displayText.endsWith(" ")) {
                waitingForOperand = true
            }

            // Si l'affichage devient complètement vide
            if (displayText.isEmpty()) {
                isNewNumber = true
                waitingForOperand = false
            }
        }

        Log.d(TAG, "Delete: removed last char, display='$displayText'")
        updateDisplay()
    }

    /**
     * Gérer le clic sur le bouton d'effacement (Reset)
     * Exigence: Efface toute la ligne d'affichage
     */
    private fun onClearClick() {
        displayText = ""
        firstOperand = null
        currentOperation = null
        isNewNumber = true
        waitingForOperand = false
        updateDisplay()
    }

    /**
     * Copier le résultat du calcul dans le presse-papiers
     * Exigence: Il doit être possible de copier le résultat du calcul dans le presse-papiers
     */
    private fun copyToClipboard() {
        if (displayText.isEmpty()) return

        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = ClipData.newPlainText("Résultat Calculatrice", displayText)
        clipboard.setPrimaryClip(clip)

        Toast.makeText(this, "Copié dans le presse-papiers", Toast.LENGTH_SHORT).show()
    }

    /**
     * Mettre à jour le TextView d'affichage avec le texte actuel
     */
    private fun updateDisplay() {
        // Exigence: Effacement du dernier chiffre ne doit pas afficher un zéro par défaut
        // Donc on affiche le texte tel quel, même vide.
        binding.displayText.text = displayText
        Log.d(TAG, "Display updated: '$displayText'")
    }
}
